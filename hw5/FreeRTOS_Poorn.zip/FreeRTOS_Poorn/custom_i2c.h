/*
 * custom_i2c.h
 *
 *  Created on: Apr 10, 2019
 *      Author: poorn
 */

#ifndef CUSTOM_I2C_H_
#define CUSTOM_I2C_H_





#endif /* CUSTOM_I2C_H_ */
