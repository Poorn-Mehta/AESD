/*
 * alert_task.h
 *
 *  Created on: Apr 10, 2019
 *      Author: poorn
 */

#ifndef ALERT_TASK_H_
#define ALERT_TASK_H_

#include "main.h"

extern void cust_print(char *txt);
void Alert_Task(void *pvParameters);


#endif /* ALERT_TASK_H_ */
