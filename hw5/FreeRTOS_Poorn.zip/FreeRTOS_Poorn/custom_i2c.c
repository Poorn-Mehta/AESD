/*
 * custom_i2c.c
 *
 *  Created on: Apr 10, 2019
 *      Author: poorn
 */




