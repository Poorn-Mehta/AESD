/* FreeRTOS 8.2 Tiva Demo
 *
 * main.c
 *
 * Base project Credits: Andy Kobyljanec
 * I2C driver is based on sources provided by TI
 *
 * This is a simple demonstration project of FreeRTOS 8.2 on the Tiva Launchpad
 * EK-TM4C1294XL.  TivaWare driverlib sourcecode is included.
 */

#include "main.h"

#include <stdint.h>
#include <stdbool.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/timer.h"
#include "driverlib/fpu.h"

// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"

#include "sensorlib/i2cm_drv.h"
#include "driverlib/i2c.h"
#include "inc/hw_i2c.h"

// FreeRTOS includes
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "Temp_Task.h"
#include "LED_Task.h"
#include "Log_Task.h"
#include "alert_task.h"

//struct tasks_data{
//    uint32_t ms_from_boot;
//    uint8_t task_flags;
//};

struct tasks_data info;
struct tasks_data *info_ptr = &info;

//struct ipc_data{
//    char name[10];
//    uint32_t led_time;
//    uint32_t led_count;
//    uint32_t temp_time;
//    float temp_value;
//    uint8_t sender;
//};

QueueHandle_t log_queue;

TaskHandle_t alert_task_handle;

uint8_t i2c_data[2];

uint8_t led_state = false;

uint32_t fun_resp = 0;

char msg[50];

void UARTSend(const uint8_t *pui8Buffer, uint32_t ui32Count)
{
    while(ui32Count--)
    {
        ROM_UARTCharPut(UART0_BASE, *pui8Buffer++);
    }
}

void cust_print(char *txt)
{
    UARTSend((uint8_t *)txt, strlen(txt));
}

void T0ISR(void)
{
    ROM_TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    info_ptr->ms_from_boot += 1;
    if((info_ptr->ms_from_boot % LED_Period_ms) == 0)     info_ptr->task_flags |= LED_TASK_EN;
    if((info_ptr->ms_from_boot % Temp_Period_ms) == 0)     info_ptr->task_flags |= TEMP_TASK_EN;
}

void custom_timer_init(void)
{
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    ROM_TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    ROM_TimerLoadSet(TIMER0_BASE, TIMER_A, (SYSTEM_CLOCK/1000));
    ROM_IntMasterEnable();
    TimerIntRegister(TIMER0_BASE, TIMER_A, T0ISR);
    ROM_IntEnable(INT_TIMER0A);
    ROM_TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    ROM_TimerEnable(TIMER0_BASE, TIMER_A);
    cust_print("\nTimer Init Success");
}

// Main function
int main(void)
{
    // Initialize system clock to 120 MHz
    uint32_t output_clock_rate_hz;
    output_clock_rate_hz = ROM_SysCtlClockFreqSet(
                               (SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                               SYSTEM_CLOCK);
    ASSERT(output_clock_rate_hz == SYSTEM_CLOCK);

    // Initialize the GPIO pins for the Launchpad
    PinoutSet(false, false);

    // Set up the UART which is connected to the virtual COM port
    UARTStdioConfig(0, 115200, SYSTEM_CLOCK);

    info_ptr->ms_from_boot = 0;
    info_ptr->task_flags = 0;

    custom_timer_init();
    tmp102_i2c_init();

    // Stack sizes are manually fine tuned

    if(xTaskCreate(Log_Task, (const portCHAR *)"Log",
                400, 0, 1, NULL) != pdTRUE)
    {
        cust_print("\nLOG Task Creation Failed");
    }
    else        cust_print("\nLOG Task Created");

    if(xTaskCreate(LED_Task, (const portCHAR *)"LEDs",
                250, (void *)info_ptr, 1, NULL) != pdTRUE)
    {
        cust_print("\nLED Task Creation Failed");
    }
    else        cust_print("\nLED Task Created");

    if(xTaskCreate(Alert_Task, (const portCHAR *)"Alert",
               300, (void *)info_ptr, 1, NULL) != pdTRUE)
    {
        cust_print("\nAlert Task Creation Failed");
    }
    else        cust_print("\nAlert Task Created");

    if(xTaskCreate(Temp_Task, (const portCHAR *)"Temp",
               300, (void *)info_ptr, 1, NULL) != pdTRUE)
    {
        cust_print("\nTEMP Task Creation Failed");
    }
    else        cust_print("\nTEMP Task Created");


    vTaskStartScheduler();
    return 0;
}


/*  ASSERT() Error function
 *
 *  failed ASSERTS() from driverlib/debug.h are executed in this function
 */
void __error__(char *pcFilename, uint32_t ui32Line)
{
    // Place a breakpoint here to capture errors until logging routine is finished
    while (1)
    {
    }
}
