/*
 * Temp_Task.h
 *
 *  Created on: Apr 10, 2019
 *      Author: poorn
 */

#ifndef Log_TASK_H_
#define Log_TASK_H_

#include "main.h"

extern void cust_print(char *txt);
void Log_Task(void *pvParameters);


#endif /* Log_TASK_H_ */
