/*
 * Temp_Task.h
 *
 *  Created on: Apr 10, 2019
 *      Author: poorn
 */

#ifndef LED_TASK_H_
#define LED_TASK_H_

#include "main.h"

extern void cust_print(char *txt);
void LED_Task(void *pvParameters);


#endif /* LED_TASK_H_ */
